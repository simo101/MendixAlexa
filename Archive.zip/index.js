var Alexa = require('alexa-sdk');

var handlers = {
    'LaunchRequest': function(){
        this.emit('AskLuckyNumber');
    },
    'AskLuckyNumber':function(){
        this.emit(':ask','What is your number? Tell me by saying my lucky number is.', 'Let me know your number');
    },
    'SetLuckyNumber':function(){
        this.emit(':tell', 'Your lucky number is ' +  parseInt(this.event.request.intent.slots.NUMBER.value));
    },
    'AMAZON.HelpIntent':function(){
        this.emit(':ask','To use this app say my number is','You can use the app by saying my number is');
    }
};

exports.handler = function(event, context, callback){
    var alexa = Alexa.handler(event, context);
    alexa.registerHandlers(handlers);
    alexa.execute();
};